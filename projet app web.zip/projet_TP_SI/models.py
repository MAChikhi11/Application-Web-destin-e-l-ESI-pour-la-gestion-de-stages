from datetime import date
from django.db import models
from GestionStages.settings import DATE_INPUT_FORMATS
from django import forms
from django.core.validators import EmailValidator
from djangoyearlessdate.models import YearlessDateField

NUMBER_OF_SECTIONS = 2

def check_section(value) :
    if value > NUMBER_OF_SECTIONS:
        raise forms.ValidationError("Numéro de section invalide")

def check_niveau(value) :
        if value not in ['1CPI','2CPI','1CS','2CS','3CS'] : 
            raise forms.ValidationError("Le niveau doit etre : '1CPI','2CPI','1CS','2CS','3CS' ")

def check_numero(value) : #Le numero ne doit pas commencer par 0
    n = len(str(value))
    if n != 9 :
        raise forms.ValidationError("Numero non valide")

def get_type_stage(id_stage) : 
    id_type_stage = (Stage.objects.filter(pk=id_stage).values())[0]['nom_type_id'] 
    p = Type_de_stage.objects.filter(pk=id_type_stage).values()
    type_stage = p[0]['nom_type'] 
    return type_stage


# Create your models here.
class Etudiant (models.Model):
    nom_et = models.CharField(max_length=40,null=False)
    prenom_et = models.CharField(max_length=40,null=False)
    date_naissance_et = models.DateField(null=False)
    section = models.PositiveSmallIntegerField(null=False, validators=[check_section])
    tel_et = models.PositiveIntegerField(null=False,validators=[check_numero])
    courriel_et = models.EmailField(max_length=40,null=False)
    adresse_et = models.CharField(max_length=80,null=False)
    niveau_scolaire = models.CharField(max_length=4,null=False,validators=[check_niveau])

    def __str__(self) :
        return "(id=" + str(self.pk)+ ") "+ self.nom_et + ' ' + self.prenom_et

class Entreprise (models.Model):
    nom_ent = models.CharField(max_length=40,null=False)
    adresse_ent = models.CharField(max_length=80,null=False)
    secteur_ent = models.CharField(max_length=40,null=False)
    tel_ent = models.PositiveIntegerField(null=False,validators=[check_numero])
    courriel_ent = models.EmailField(max_length=40,null=False)

    def __str__(self) :
        return "(id=" + str(self.pk)+ ") " + self.nom_ent

class Type_de_stage(models.Model) :  
    nom_type = models.CharField(primary_key=True,max_length=40) 
    date_debut_min = YearlessDateField(null=True) 
    date_fin_max = YearlessDateField(null=True)
    duree_min = models.PositiveSmallIntegerField() #in weeks
    duree_max = models.PositiveSmallIntegerField() #in weeks 
    nbr_personne = models.PositiveSmallIntegerField() # monome, binome ...
    def __str__(self) :
        return self.nom_type

class Enseignant (models.Model):
    nom_ens = models.CharField(max_length=80,null=False)
    prenom_ens = models.CharField(max_length=80,null=False)
    tel_ens = models.PositiveIntegerField(null=False,validators=[check_numero])
    courriel_ens = models.EmailField(max_length=40,null=False)
    adresse_ens = models.CharField(max_length=80,null=False)

    def __str__(self) :
        return "(id=" + str(self.pk)+ ") " + self.nom_ens + ' ' + self.prenom_ens


class Membre(models.Model) :  
    nom_me = models.CharField(max_length = 40) 
    prenom_me = models.CharField(max_length = 40) 
    fonction_me = models.CharField(max_length = 40) 
    tel_me = models.PositiveIntegerField(null=False,validators=[check_numero]) 
    courriel_me = models.EmailField(max_length=40,null=False) 
    adresse_me = models.CharField(max_length=40) 
    id_entreprise = models.ForeignKey(Entreprise,on_delete=models.CASCADE) 

    def __str__(self) :
        return "(id=" + str(self.pk)+ ") " + self.nom_me + ' ' + self.prenom_me

class Stage (models.Model):
    sujet_stage = models.CharField(max_length=80,null=False)
    dateDeb = models.DateField(null=False) 
    dateFin = models.DateField(null=False) 
    id_entreprise = models.ForeignKey(Entreprise ,on_delete=models.CASCADE, null=False)
    nom_type = models.ForeignKey(Type_de_stage,on_delete=models.CASCADE,null=False)
    id_enseignant = models.ForeignKey(Enseignant , on_delete=models.CASCADE,blank=True, null=True)
    id_membre = models.ForeignKey(Membre , on_delete=models.CASCADE , null=False)
    etudiants = models.ManyToManyField(Etudiant)
    date_soutenance = models.DateField()
    
    def __str__(self) :
        return "(id=" + str(self.pk)+ ") " + self.sujet_stage

class Rapport(models.Model) :  
    nb_pages = models.PositiveSmallIntegerField() 
    id_stage = models.ForeignKey(Stage,on_delete=models.CASCADE,default=None,null=False) 

    def __str__(self) :
        return "(id=" + str(self.pk)+ ") " + "rapport stage ["+ self.id_stage+"]"

class Convention (models.Model): 
    id_stage = models.ForeignKey(Stage , on_delete=models.CASCADE,default=None,null=False) 

    def __str__(self) :
        return "(id=" + str(self.pk)+ ") " + "convention stage ["+ self.id_stage+"]"


# Fonctions pour fiche de suivi et fiche d'evaluation 
#//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
def compter(id_stage):
        count = Fiche_de_suivi.objects.filter(id_stage=id_stage).count()
        return count

def check_stage_fiche_s(value) : 
    type_stage = get_type_stage(value)
    if (compter(value)>=3) or (type_stage!='3CS') :
        raise forms.ValidationError("Ce stage a déja 3 fiches de suivi ou n\'est pas de type 3CS") 

class Fiche_de_suivi(models.Model) :  
    date_fiche_s = models.DateField() 
    id_stage= models.ForeignKey(Stage,on_delete=models.CASCADE, null=False,validators=[check_stage_fiche_s])

    def __str__(self) :
        return "(id=" + str(self.pk)+ ") " + "Fiche suivi stage ["+ self.id_stage+"]"

def check_stage_fiche_e(value):
    type_stage = get_type_stage(value)
    if ((type_stage!='1CS') and (type_stage!='3CS')):
        raise forms.ValidationError('Ce stage n\'a pas de fiche d\'évaluation')
#//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////       


class Fiche_evaluation(models.Model) : 
    id_stage = models.ForeignKey(Stage,on_delete=models.CASCADE,null=False,validators=[check_stage_fiche_e]) 

    def __str__(self) :
        return "(id=" + str(self.pk)+ ") " + "Fiche evaluation stage ["+ self.id_stage+"]"    