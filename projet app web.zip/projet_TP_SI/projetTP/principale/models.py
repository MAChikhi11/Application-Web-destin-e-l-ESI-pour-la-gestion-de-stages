from datetime import date
from django.db import models

# Create your models here.
class Etudiant (models.Model):
    nom_et = models.CharField(max_length=40,null=False)
    prenom_et = models.CharField(max_length=40,null=False)
    date_naissance_et = models.DateField(null=False)
    section = models.IntegerField(null=False)
    tel_et = models.IntegerField(null=False)
    courriel_et = models.CharField(max_length=40,null=False)
    adresse_et = models.CharField(max_length=80,null=False)

class Entreprise (models.Model):
    nom_ent = models.CharField(max_length=40,null=False)
    adresse_ent = models.CharField(max_length=80,null=False)
    secteur_ent = models.CharField(max_length=40,null=False)
    tel_ent = models.IntegerField(null=False)
    courriel_ent = models.CharField(max_length=40,null=False)

class Type_de_stage(models.Model) :  
    nom_type = models.CharField(max_length=40) 
    date_debut_min = models.DateField() 
    date_fin_max = models.DateField() 

class Enseignant (models.Model):
    nom_ens = models.CharField(max_length=80,null=False)
    prenom_ens = models.CharField(max_length=80,null=False)
    tel_ens = models.IntegerField(null=False)
    courriel_ens = models.CharField(max_length=40,null=False)
    adresse_ens = models.CharField(max_length=80,null=False)


class Membre(models.Model) :  
    nom_me = models.CharField(max_length = 40) 
    prenom_me = models.CharField(max_length = 40) 
    fonction_me = models.CharField(max_length = 40) 
    tel_me = models.PositiveIntegerField() 
    courriel_me = models.CharField(max_length = 40) 
    adresse_me = models.CharField(max_length=40) 
    id_entreprise = models.ForeignKey(Entreprise,on_delete=models.CASCADE) 

class Stage (models.Model):
    sujet_stage = models.CharField(max_length=80,null=False)
    id_entreprise = models.ForeignKey(Entreprise ,on_delete=models.CASCADE, null=False)
    nom_type = models.ForeignKey(Type_de_stage,on_delete=models.CASCADE,null=False)
    #id_rapport = models.ForeignKey(Rapport , on_delete=models.CASCADE,null=False)
    id_enseignant = models.ForeignKey(Enseignant , on_delete=models.CASCADE)
    id_membre = models.ForeignKey(Membre , on_delete=models.CASCADE , null=False)
    #id_fiche_e = models.ForeignKey(Fiche_evaluation , on_delete=models.CASCADE)
    #id_convention = models.ForeignKey(Convention , on_delete=models.CASCADE,null=False)

class Rapport(models.Model) :  
    nb_pages = models.PositiveIntegerField() 
    id_stage = models.ForeignKey(Stage,on_delete=models.CASCADE,default=None,null=False) 

class Fiche_evaluation(models.Model) : 
    id_stage = models.ForeignKey(Stage,on_delete=models.CASCADE,default=None,null=False) 
    id_membre = models.ForeignKey(Membre,on_delete=models.CASCADE)
    def verif (self,id_stage):
        p = Fiche_evaluation.objects.raw('SELECT * FROM principale_Stage WHERE id_stage = %d',[id_stage]) 
        return p.nom_type

    def __init__(self,id_stage,id_membre):
        if ((self.verif(id_stage)=='1CS') or(self.verif(id_stage)=='3CS')):
           self.id_stage=id_stage
           self.id_membre=id_membre 
        else :
            print('ce stage n\'a pas de fiche d\'evaluation')

class Convention (models.Model): 
    id_entreprise = models.ForeignKey(Entreprise, on_delete=models.CASCADE)
    id_stage = models.ForeignKey(Stage , on_delete=models.CASCADE,default=None,null=False) 

class Fiche_de_suivi(models.Model) :  
    date_fiche_s = models.DateField() 
    id_stage= models.ForeignKey(Stage,on_delete=models.CASCADE,default=None, null=False) 
    id_membre= models.ForeignKey(Membre,on_delete=models.CASCADE) 
    id_enseignant= models.ForeignKey(Enseignant,on_delete=models.CASCADE) 
    def compter (self,id_stage2):
        count = 0
        for p in Fiche_de_suivi.objects.raw('SELECT * FROM principale_Fiche_de_suivi WHERE id_stage = %d',[id_stage2])  :
            count += 1
        return count

    def verif_pfe (self,id_stage2):
        p = Fiche_de_suivi.objects.raw('SELECT * FROM principale_Stage WHERE id_stage = %d',[id_stage2]) 
        return p.nom_type

    def __init__(self,date_fiche_s,id_stage,id_membre,id_enseignant):
       if (self.compter(id_stage)<3) and (self.verif(id_stage)=='3CS') :
           self.date_fiche_s=date_fiche_s
           self.id_stage=id_stage
           self.id_enseignant=id_enseignant
           self.id_membre=id_membre
       else : 
            print('ce stage a déja 3 fiches de suivi ou n est pas de type 3CS')
       
    

class Realise(models.Model) :  
    id_etudiant = models.ForeignKey(Etudiant,on_delete=models.CASCADE) 
    id_stage = models.ForeignKey(Stage,on_delete=models.CASCADE) 
    dateDeb = models.DateField() 
    dateFin = models.DateField() 

class Signer(models.Model) :  
    #COMPOSITE FOREGIN KEY 
    id_etudiant = models.ForeignKey(Etudiant,on_delete=models.CASCADE) 
    id_convention = models.ForeignKey(Convention, on_delete=models.CASCADE) 



