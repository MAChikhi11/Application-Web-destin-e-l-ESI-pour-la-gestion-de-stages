from django.shortcuts import render ,redirect

from principale.form import EnseignantForm, EtudiantForm
from .models import Enseignant
# Create your views here.

def index (request):
    return render(request,'index.html')

def create_enseignant (request):
    mssg=""
    if request.method == "POST":
        form= EnseignantForm(data=request.POST)
        if form.is_valid():
            form.save()
            return redirect("index")
        
    else : 
        form = EnseignantForm()
        
    return render(request,'create_enseignant.html',{"form":form})

def create_etudiant (request) : 
    mssg=""
    form=""
    if request.method == 'POST' : 
        form =  EtudiantForm(request.POST)
        if form.is_valid() :
            form.save()
            form = EtudiantForm()
            mssg="Etudiant envoyé; vous pouvez saisir un autre"
        return render(request,"create_etudiant.html",{"form" : form,"message" : mssg})
    else:
        form =  EtudiantForm() 
        mssg="Veuillez remplir tous les champs "
        return render(request,"create_etudiant.html",{"form" : form,"message" : mssg})