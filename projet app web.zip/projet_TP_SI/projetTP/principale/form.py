from django.forms import ModelForm
from .models import Enseignant,Etudiant
from django.db.models import fields
class EnseignantForm (ModelForm):
    class Meta:
        model = Enseignant
        fields = "__all__"

class EtudiantForm (ModelForm) : 
    class Meta :
        model = Etudiant
        fields="__all__"