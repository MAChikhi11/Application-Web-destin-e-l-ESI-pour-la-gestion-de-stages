from django.db.models import fields
from django import forms 
from django.forms import Textarea
from .models import *

class EtudiantForm (forms.ModelForm) : 
    class Meta :
        model = Etudiant
        fields="__all__"


class EntrepriseForm (forms.ModelForm) : 
    class Meta :
        model = Entreprise
        fields="__all__"

class TypeStageForm (forms.ModelForm) : 
    def clean(self) : 
        cleaned_data = super().clean()
        date_min = cleaned_data.get("date_debut_min")
        date_max = cleaned_data.get("date_fin_max")
    
        if date_min.month > date_max.month : 
            raise forms.ValidationError("La date de debut est plus grande que la date de fin")
        elif date_min.month == date_max.month : 
            if date_min.day > date_max.day : 
                raise forms.ValidationError("La date de debut est plus grande que la date de fin")
            elif date_min.day == date_max.day : 
                raise forms.ValidationError("La date de debut est égale a la date de fin")
    class Meta :
        model = Type_de_stage
        fields="__all__"

class EnseignantForm (forms.ModelForm) : 
    class Meta :
        model = Enseignant
        fields="__all__"


class MembreForm (forms.ModelForm) : 
    class Meta :
        model = Membre
        fields="__all__"

class StageForm (forms.ModelForm) : 
    def clean(self) :
        cleaned_data = super().clean()
        date_d = cleaned_data.get("dateDeb")
        date_f = cleaned_data.get("dateFin")
        nom_t = cleaned_data.get("nom_type")
        ens = cleaned_data.get("id_enseignant")
        nbr_etu= cleaned_data.get("etudiants").count()
        
        duree_stage = (date_f - date_d).days # en jours 

        p = Type_de_stage.objects.filter(nom_type = nom_t).values()
        date_min = p[0]['date_debut_min']
        date_max = p[0]['date_fin_max']
        duree_min = p[0]['duree_min'] * 7 # pour avoir la duree en jours 
        duree_max = p[0]['duree_max'] * 7 # pour avoir la duree en jours
        nbr_max = p[0]['nbr_personne'] #nombre d'etudiant maximum partcipant en groupe au stage  

        if date_d > date_f : 
            raise forms.ValidationError("Date debut est plus grande que date fin")

        if nom_t != "3CS" and ens != None :
             raise forms.ValidationError("Ce stage n'est pas encadré par un enseignant")

        #verifier que date_d est plus grande que date_min
        if date_d.month < date_min.month : 
            raise forms.ValidationError("La date de debut de stage n\'est pas respecté")
        elif date_d.month == date_min.month: 
            if date_d.day < date_min.day : 
                raise forms.ValidationError("La date de debut de stage n\'est pas respecté")

        #verifier que date_f est plus petite que date_max
        if date_f.month > date_max.month : 
            raise forms.ValidationError("La date de fin de stage n\'est pas respecté")
        elif date_f.month == date_max.month : 
            if date_f.day > date_max.day : 
                raise forms.ValidationError("La date de fin de stage n\'est pas respecté")
        
        #verifier la duree du stage
        if duree_stage < duree_min or duree_stage > duree_max  : 
            raise forms.ValidationError("La durée du stage n\'est pas respecté")

        if nbr_etu > nbr_max : 
            raise forms.ValidationError("Le nombre d\'etudiants n\'est pas valide pour ce type de stage")
        
    class Meta :
        model = Stage
        fields="__all__"

class RapportForm (forms.ModelForm) : 
    class Meta :
        model = Rapport
        fields="__all__"

class FicheEvaluationForm (forms.ModelForm) : 
    class Meta :
        model = Fiche_evaluation
        fields="__all__"

class ConventionForm (forms.ModelForm) : 
    class Meta :
        model = Convention
        fields="__all__"


class FicheSuiviForm (forms.ModelForm) : 
    class Meta :
        model = Fiche_de_suivi
        fields="__all__"
