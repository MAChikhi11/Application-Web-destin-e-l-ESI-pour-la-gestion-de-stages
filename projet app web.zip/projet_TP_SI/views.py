from django.shortcuts import render
from .forms import *
from .models import *
# Create your views here.

def creer_etudiant (request) : 
    mssg=""
    form=""
    if request.method == 'POST' : 
        form =  EtudiantForm(request.POST)
        if form.is_valid() :
            form.save()
            form = EtudiantForm()
            mssg="Etudiant envoyé; vous pouvez saisir un autre"
        return render(request,"create_et.html",{"form" : form,"message" : mssg})
    else:
        form =  EtudiantForm() 
        mssg="Veuillez remplir tous les champs "
        return render(request,"create_et.html",{"form" : form,"message" : mssg})

def creer_entreprise (request) : 
    mssg=""
    form=""
    if request.method == 'POST' : 
        form =  EntrepriseForm(request.POST)
        if form.is_valid() :
            form.save()
            form = EntrepriseForm()
            mssg="Entreprise envoyé; vous pouvez saisir un autre"
        return render(request,"create_ent.html",{"form" : form,"message" : mssg})
    else:
        form =  EntrepriseForm()
        mssg="Veuillez remplir tous les champs "
        return render(request,"create_ent.html",{"form" : form,"message" : mssg})

def creer_type_de_stage (request) : 
    mssg=""
    form=""
    if request.method == 'POST' : 
        form =  TypeStageForm(request.POST)
        if form.is_valid() :
            form.save()
            form = TypeStageForm()
            mssg="Type de stage envoyé; vous pouvez saisir un autre"
        return render(request,"create_type_st.html",{"form" : form,"message" : mssg})
    else:
        form =  TypeStageForm()
        mssg="Veuillez remplir tous les champs "
        return render(request,"create_type_st.html",{"form" : form,"message" : mssg})

def creer_enseignant (request) : 
    mssg=""
    form=""
    if request.method == 'POST' : 
        form =  EnseignantForm(request.POST)
        if form.is_valid() :
            form.save()
            form = EnseignantForm()
            mssg="Enseignant envoyé; vous pouvez saisir un autre"
        return render(request,"create_ens.html",{"form" : form,"message" : mssg})
    else:
        form =  EnseignantForm() 
        mssg="Veuillez remplir tous les champs "
        return render(request,"create_ens.html",{"form" : form,"message" : mssg})

def creer_membre (request) : 
    mssg=""
    form=""
    if request.method == 'POST' : 
        form =  MembreForm(request.POST)
        if form.is_valid() :
            form.save()
            form = MembreForm()
            mssg="Membre envoyé; vous pouvez saisir un autre"
        return render(request,"create_me.html",{"form" : form,"message" : mssg})
    else:
        form =  MembreForm()
        mssg="Veuillez remplir tous les champs "
        return render(request,"create_me.html",{"form" : form,"message" : mssg})

def creer_stage (request) : 
    mssg=""
    form=""
    if request.method == 'POST' : 
        form =  StageForm(request.POST)
        if form.is_valid() :
            form.save()
            form = StageForm()
            mssg="Stage envoyé; vous pouvez saisir un autre"
        return render(request,"create_st.html",{"form" : form,"message" : mssg})
    else:
        form =  StageForm()
        mssg="Veuillez remplir tous les champs "
        return render(request,"create_st.html",{"form" : form,"message" : mssg})


def creer_rapport (request) : 
    mssg=""
    form=""
    if request.method == 'POST' : 
        form =  RapportForm(request.POST)
        if form.is_valid() :
            form.save()
            form = RapportForm()
            mssg="Rapport envoyé; vous pouvez saisir un autre"
        return render(request,"create_ra.html",{"form" : form,"message" : mssg})
    else:
        form =  RapportForm()
        mssg="Veuillez remplir tous les champs "
        return render(request,"create_ra.html",{"form" : form,"message" : mssg})

def creer_fiche_e (request) : 
    mssg=""
    form=""
    if request.method == 'POST' : 
        form =  FicheEvaluationForm(request.POST)
        if form.is_valid() :
            form.save()
            form = FicheEvaluationForm()
            mssg="Fiche d'evaluation envoyé; vous pouvez saisir un autre"
        return render(request,"create_fiche_e.html",{"form" : form,"message" : mssg})
    else:
        form =  FicheEvaluationForm()
        mssg="Veuillez remplir tous les champs "
        return render(request,"create_fiche_e.html",{"form" : form,"message" : mssg})

def creer_convention (request) : 
    mssg=""
    form=""
    if request.method == 'POST' : 
        form =  ConventionForm(request.POST)
        if form.is_valid() :
            form.save()
            form = ConventionForm()
            mssg="Convention envoyé; vous pouvez saisir un autre"
        return render(request,"create_conv.html",{"form" : form,"message" : mssg})
    else:
        form =  ConventionForm()
        mssg="Veuillez remplir tous les champs "
        return render(request,"create_conv.html",{"form" : form,"message" : mssg})



def creer_fiche_s (request) : 
    mssg=""
    form=""
    if request.method == 'POST' : 
        form =  FicheSuiviForm(request.POST)
        if form.is_valid() :
            form.save()
            form = FicheSuiviForm()
            mssg="Fiche de suivi envoyé; vous pouvez saisir un autre"
        return render(request,"create_fiche_s.html",{"form" : form,"message" : mssg})
    else:
        form =  FicheSuiviForm()
        mssg="Veuillez remplir tous les champs "
        return render(request,"create_fiche_s.html",{"form" : form,"message" : mssg})

#def creer_realise (request) : 
    mssg=""
    form=""
    if request.method == 'POST' : 
        form =  RealiseForm(request.POST)
        if form.is_valid() :
            form.save()
            form = RealiseForm()
            mssg="Realise envoyé; vous pouvez saisir un autre"
        return render(request,"create_re.html",{"form" : form,"message" : mssg})
    else:
        form =  RealiseForm()
        mssg="Veuillez remplir tous les champs "
        return render(request,"create_re.html",{"form" : form,"message" : mssg})

